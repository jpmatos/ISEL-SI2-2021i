CREATE TRIGGER stopInvoiceDeletion
    ON Invoice
    INSTEAD OF DELETE
    AS
BEGIN
    DECLARE @code NVARCHAR(12)
    DECLARE cursor_code CURSOR FOR
        SELECT code FROM deleted
    OPEN cursor_code
    FETCH NEXT FROM cursor_code INTO @code
    WHILE @@FETCH_STATUS = 0
        BEGIN
            EXEC updateInvoiceState @code, 'canceled'
            FETCH NEXT FROM cursor_code INTO @code
        END
END
go

