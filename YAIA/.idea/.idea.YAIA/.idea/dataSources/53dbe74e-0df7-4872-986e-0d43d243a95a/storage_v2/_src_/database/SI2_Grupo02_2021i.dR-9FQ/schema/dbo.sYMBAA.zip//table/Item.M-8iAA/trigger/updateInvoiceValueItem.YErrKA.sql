--Will trigger even if only description was updated
CREATE TRIGGER updateInvoiceValueItem
    ON Item
    AFTER INSERT, UPDATE, DELETE
    AS
BEGIN
    DECLARE @codes CodesListType
    INSERT INTO @codes SELECT code FROM inserted
    INSERT INTO @codes SELECT code FROM deleted
    EXEC updateInvoiceValue @codes
END
go

