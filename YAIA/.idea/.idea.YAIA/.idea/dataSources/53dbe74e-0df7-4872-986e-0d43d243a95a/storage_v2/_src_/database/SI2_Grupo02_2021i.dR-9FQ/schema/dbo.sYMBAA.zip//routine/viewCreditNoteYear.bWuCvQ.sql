CREATE FUNCTION viewCreditNoteYear(@year INT)
    RETURNS TABLE AS
        RETURN
            (
                SELECT *
                FROM CreditNote
                WHERE YEAR(creation_date) = @year
            )
go

