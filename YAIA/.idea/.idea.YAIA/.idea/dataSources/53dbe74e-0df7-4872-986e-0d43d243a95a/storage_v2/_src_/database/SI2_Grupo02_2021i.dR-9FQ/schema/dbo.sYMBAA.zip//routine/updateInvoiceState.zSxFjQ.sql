CREATE PROCEDURE updateInvoiceState @code NVARCHAR(12), @state NVARCHAR(16)
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
    BEGIN TRAN
        IF (SELECT COUNT(*) FROM InvoiceState WHERE state = @state) = 0
            THROW 50000, 'Invalid Invoice state', 1

        DECLARE @current NVARCHAR(12)
        SELECT @current = state FROM Invoice WHERE code = @code

        IF (@current = 'emitted' OR @current = 'canceled')
            THROW 50000, 'Can not change Invoice state!', 1

        IF (@current = 'proforma' AND @state = 'updating')
            THROW 50000, 'Invalid Invoice state change!', 1

        IF ((@current = 'proforma' AND @state = 'proforma') OR
            (@current = 'updating' AND @state = 'updating'))
            THROW 50000, 'Invoice already in the specified state!', 1

        if (@state = 'emitted')
            UPDATE Invoice SET state = @state, emission_date = GETDATE() WHERE code = @code
        ELSE
            UPDATE Invoice SET state = @state WHERE code = @code
    COMMIT
END
go

