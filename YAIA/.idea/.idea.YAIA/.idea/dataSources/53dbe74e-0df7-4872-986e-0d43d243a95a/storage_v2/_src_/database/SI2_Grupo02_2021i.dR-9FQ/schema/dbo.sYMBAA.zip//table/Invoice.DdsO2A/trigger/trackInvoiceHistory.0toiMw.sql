CREATE TRIGGER trackInvoiceHistory
    ON Invoice
    AFTER UPDATE, INSERT
    AS
BEGIN
    DECLARE @date DATETIME = GETDATE()
    INSERT INTO InvoiceHistory (code, alteration_date, NIF, state, total_value, total_IVA, creation_date, emission_date)
    SELECT code,
           @date,
           NIF,
           state,
           total_value,
           total_IVA,
           creation_date,
           emission_date
    FROM inserted
    WHERE NOT EXISTS(SELECT * FROM InvoiceHistory IC WHERE IC.code = code AND IC.alteration_date = @date)
END
go

