CREATE PROCEDURE updateProduct @SKU NVARCHAR(10), @sale_price MONEY, @IVA DECIMAL(3, 2),
                               @description NVARCHAR(128)
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
    BEGIN TRAN
        IF NOT EXISTS(SELECT *
                      FROM Product
                      WHERE Product.SKU = @SKU)
            BEGIN
                ROLLBACK;
                THROW 51404, 'Product with SKU was not found!', 1
            END

        SELECT *
        INTO #Temp
        FROM Product
        WHERE SKU = @SKU
        UPDATE Product
        SET description = ISNULL(@description, (SELECT description FROM #Temp)),
            sale_price  = ISNULL(@sale_price, (SELECT sale_price FROM #Temp)),
            IVA         = ISNULL(@IVA, (SELECT IVA FROM #Temp))
        WHERE SKU = @SKU
    COMMIT
END
go

