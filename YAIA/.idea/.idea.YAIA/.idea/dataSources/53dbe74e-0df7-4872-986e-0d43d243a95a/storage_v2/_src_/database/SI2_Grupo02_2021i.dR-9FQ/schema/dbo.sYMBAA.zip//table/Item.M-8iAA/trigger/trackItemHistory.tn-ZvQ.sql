CREATE TRIGGER trackItemHistory
    ON Item
    AFTER UPDATE, INSERT
    AS
BEGIN
    DECLARE @code NVARCHAR(12)
    DECLARE cursor_code CURSOR FOR
        SELECT DISTINCT code FROM inserted
    OPEN cursor_code
    FETCH NEXT FROM cursor_code INTO @code
    WHILE @@FETCH_STATUS = 0
        BEGIN
            DECLARE @date DATETIME = GETDATE()

            INSERT INTO InvoiceHistory (code, alteration_date, NIF, state, total_value, total_IVA, creation_date,
                                        emission_date)
            SELECT code,
                   @date,
                   NIF,
                   state,
                   total_value,
                   total_IVA,
                   creation_date,
                   emission_date
            FROM Invoice I
            WHERE I.code = @code
              AND NOT EXISTS(SELECT * FROM InvoiceHistory IC WHERE IC.code = code AND IC.alteration_date = @date)

            INSERT INTO ItemHistory(code, alteration_date, SKU, sale_price, IVA, units, discount, description)
            SELECT code,
                   @date,
                   SKU,
                   sale_price,
                   IVA,
                   units,
                   discount,
                   description
            FROM inserted
            WHERE inserted.code = @code
            FETCH NEXT FROM cursor_code INTO @code
        END
    CLOSE cursor_code
    DEALLOCATE cursor_code
END
go

