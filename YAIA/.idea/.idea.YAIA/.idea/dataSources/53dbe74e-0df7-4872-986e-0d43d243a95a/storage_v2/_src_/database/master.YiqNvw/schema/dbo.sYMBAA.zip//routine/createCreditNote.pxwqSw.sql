CREATE PROCEDURE createCreditNote @invoice NVARCHAR(12), @itemList ItemListType READONLY
AS
BEGIN
    --Create CreditNote
    DECLARE @code VARCHAR(MAX)
    EXEC @code = nextCode 'creditnote'
    INSERT INTO CreditNote VALUES (@code, @invoice, 'updating', 0, 0, GETDATE(), NULL)

    --Update Items
    UPDATE Item SET credit_note = @code WHERE number IN (SELECT * FROM @itemList)

    --Update CreditNote total_value and total_IVA
    UPDATE CreditNote
    SET total_value = (
        SELECT SUM(sale_price * units - discount)
        FROM Item I
                 INNER JOIN Product P on I.SKU = P.SKU
        WHERE I.number IN (SELECT * FROM @itemList)
    ),
        total_IVA   = (
            SELECT SUM((sale_price + (sale_price * IVA)) * units - discount)
            FROM Item I
                     INNER JOIN Product P on I.SKU = P.SKU
            WHERE I.number IN (SELECT * FROM @itemList)
        )
    WHERE code = @code

    --Cancel Invoice
    --UPDATE Invoice SET state = 'canceled' WHERE code = @invoice
END
go

