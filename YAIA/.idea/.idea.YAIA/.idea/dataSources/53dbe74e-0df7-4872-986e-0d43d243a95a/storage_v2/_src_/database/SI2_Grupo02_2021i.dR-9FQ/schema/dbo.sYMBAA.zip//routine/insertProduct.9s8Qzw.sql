CREATE PROCEDURE insertProduct @SKU NVARCHAR(10), @sale_price MONEY, @IVA DECIMAL(3, 2),
                               @description NVARCHAR(128)
AS
BEGIN
    INSERT INTO Product
    VALUES (@SKU, @sale_price, @IVA, @description)
END
go

