CREATE PROCEDURE deleteProduct @SKU NVARCHAR(10)
AS
BEGIN
    BEGIN TRAN
        IF EXISTS(SELECT *
                  FROM Item
                  WHERE SKU = @SKU)
            BEGIN
                ROLLBACK;
                THROW 51405, 'Item exists for this Product!', 1
            END
        DELETE
        FROM Product
        WHERE SKU = @SKU
    COMMIT
END
go

