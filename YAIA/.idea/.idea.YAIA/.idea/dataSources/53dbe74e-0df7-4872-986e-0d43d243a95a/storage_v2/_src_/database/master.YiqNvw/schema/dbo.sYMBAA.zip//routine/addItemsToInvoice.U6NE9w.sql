CREATE PROCEDURE addItemsToInvoice @invoice NVARCHAR(12), @itemToAdd ItemToAddListType READONLY
AS
BEGIN
    --Add items
    INSERT INTO Item (code, SKU, units, discount, description)
    SELECT @invoice, SKU, units, discount, description
    FROM @itemToAdd
    --Recalculate Invoice values
END
go

